<?php
/**
 * Get Phame Queue
 *
 * Stores pending contact pushes in a dedicated DB table and processes them
 * via WP-Cron every 5 minutes. This decouples the sync from the order flow
 * so there is zero impact on checkout performance.
 *
 * Table: {prefix}gpc_queue
 *   id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY
 *   first_name  VARCHAR(100)
 *   last_name   VARCHAR(100)
 *   email       VARCHAR(320) NOT NULL
 *   source      VARCHAR(50)   — 'woocommerce' | 'woocommerce_bulk' | 'wordpress_user'
 *   source_id   BIGINT UNSIGNED  — order ID or user ID
 *   status      VARCHAR(20)   — 'pending' | 'sent' | 'failed' | 'skipped'
 *   attempts    TINYINT UNSIGNED DEFAULT 0
 *   last_error  TEXT
 *   created_at  DATETIME
 *   processed_at DATETIME
 *
 * @package GetPhameConnector
 */

defined( 'ABSPATH' ) || exit;

class GPC_Queue {

	const CRON_HOOK     = 'gpc_process_queue';
	const CRON_INTERVAL = 'gpc_every_6_hours';
	const MAX_ATTEMPTS  = 3;
	const BATCH_SIZE    = 30;

	// ─── Bootstrap ────────────────────────────────────────────────────────────

	public static function init(): void {
		// Register custom cron interval.
		add_filter( 'cron_schedules', array( __CLASS__, 'add_cron_interval' ) );

		// Schedule the cron job if not already scheduled.
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time(), self::CRON_INTERVAL, self::CRON_HOOK );
		}

		add_action( self::CRON_HOOK, array( __CLASS__, 'process_batch' ) );
	}

	public static function add_cron_interval( array $schedules ): array {
		$schedules[ self::CRON_INTERVAL ] = array(
			'interval' => 6 * HOUR_IN_SECONDS,
			'display'  => __( 'Every 6 Hours', 'get-phame-connector' ),
		);
		return $schedules;
	}

	// ─── Table Management ─────────────────────────────────────────────────────

	public static function create_table(): void {
		global $wpdb;

		$table_name      = $wpdb->prefix . 'gpc_queue';
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
			id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			first_name   VARCHAR(100)    NOT NULL DEFAULT '',
			last_name    VARCHAR(100)    NOT NULL DEFAULT '',
			email        VARCHAR(320)    NOT NULL,
			source       VARCHAR(50)     NOT NULL DEFAULT 'woocommerce',
			source_id    BIGINT UNSIGNED          DEFAULT NULL,
			status       VARCHAR(20)     NOT NULL DEFAULT 'pending',
			attempts     TINYINT UNSIGNED NOT NULL DEFAULT 0,
			last_error   TEXT,
			created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
			processed_at DATETIME                 DEFAULT NULL,
			PRIMARY KEY  (id),
			KEY idx_status (status),
			KEY idx_email  (email(191))
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );

		update_option( 'gpc_db_version', GPC_VERSION );
	}

	public static function drop_table(): void {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}gpc_queue" );
	}

	public static function clear_cron(): void {
		$timestamp = wp_next_scheduled( self::CRON_HOOK );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, self::CRON_HOOK );
		}
	}

	// ─── Enqueue ──────────────────────────────────────────────────────────────

	/**
	 * Add a contact to the processing queue.
	 *
	 * @param string   $first_name
	 * @param string   $last_name
	 * @param string   $email
	 * @param string   $source
	 * @param int|null $source_id
	 */
	public static function enqueue( string $first_name, string $last_name, string $email, string $source = 'woocommerce', ?int $source_id = null ): void {
		global $wpdb;

		$table = $wpdb->prefix . 'gpc_queue';

		// Deduplicate: skip if this email is already pending or sent.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$existing = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE email = %s AND status IN ('pending','sent') LIMIT 1",
				strtolower( trim( $email ) )
			)
		);

		if ( $existing ) {
			GPC_Logger::log( sprintf( 'Queue: skipped duplicate email %s.', $email ) );
			return;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->insert(
			$table,
			array(
				'first_name' => sanitize_text_field( $first_name ),
				'last_name'  => sanitize_text_field( $last_name ),
				'email'      => sanitize_email( $email ),
				'source'     => sanitize_key( $source ),
				'source_id'  => $source_id,
				'status'     => 'pending',
				'created_at' => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%d', '%s', '%s' )
		);
	}

	// ─── Process ──────────────────────────────────────────────────────────────

	/**
	 * Process a batch of pending queue items.
	 * Called by WP-Cron every 5 minutes.
	 */
	public static function process_batch(): void {
		$api_key = get_option( 'gpc_api_key', '' );
		if ( empty( $api_key ) ) {
			return;
		}

		global $wpdb;
		$table = $wpdb->prefix . 'gpc_queue';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE status = 'pending' AND attempts < %d ORDER BY created_at ASC LIMIT %d",
				self::MAX_ATTEMPTS,
				self::BATCH_SIZE
			)
		);

		if ( empty( $rows ) ) {
			return;
		}

		foreach ( $rows as $row ) {
			$result = GPC_API_Client::push_contact(
				$row->first_name,
				$row->last_name,
				$row->email,
				$api_key
			);

			$new_status = $result['success'] ? 'sent' : 'failed';
			$attempts   = (int) $row->attempts + 1;

			// If failed but under max attempts, keep as pending for retry.
			if ( ! $result['success'] && $attempts < self::MAX_ATTEMPTS ) {
				$new_status = 'pending';
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->update(
				$table,
				array(
					'status'       => $new_status,
					'attempts'     => $attempts,
					'last_error'   => $result['success'] ? null : $result['message'],
					'processed_at' => current_time( 'mysql' ),
				),
				array( 'id' => $row->id ),
				array( '%s', '%d', '%s', '%s' ),
				array( '%d' )
			);

			if ( $result['success'] ) {
				GPC_Logger::log( sprintf( 'Pushed: %s <%s> — %s', $row->first_name . ' ' . $row->last_name, $row->email, $result['created'] ? 'created' : 'already exists' ) );
			} else {
				GPC_Logger::log( sprintf( 'Failed: %s <%s> — %s (attempt %d/%d)', $row->first_name . ' ' . $row->last_name, $row->email, $result['message'], $attempts, self::MAX_ATTEMPTS ) );
			}
		}
	}

	// ─── Stats ────────────────────────────────────────────────────────────────

	/**
	 * Return queue statistics for the admin dashboard.
	 *
	 * @return array{pending: int, sent: int, failed: int, skipped: int}
	 */
	public static function get_stats(): array {
		global $wpdb;
		$table = $wpdb->prefix . 'gpc_queue';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results(
			"SELECT status, COUNT(*) as cnt FROM {$table} GROUP BY status"
		);

		$stats = array( 'pending' => 0, 'sent' => 0, 'failed' => 0, 'skipped' => 0 );
		foreach ( $rows as $row ) {
			if ( isset( $stats[ $row->status ] ) ) {
				$stats[ $row->status ] = (int) $row->cnt;
			}
		}

		return $stats;
	}

	/**
	 * Return recent queue log entries for the admin log viewer.
	 *
	 * @param int $limit
	 * @return array
	 */
	public static function get_recent( int $limit = 50 ): array {
		global $wpdb;
		$table = $wpdb->prefix . 'gpc_queue';

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table} ORDER BY created_at DESC LIMIT %d",
				$limit
			)
		);
	}
}
