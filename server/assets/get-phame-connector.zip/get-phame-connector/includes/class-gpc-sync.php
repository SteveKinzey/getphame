<?php
/**
 * Get Phame Sync
 *
 * Hooks into WooCommerce order events and WordPress user registration
 * to automatically push customer data to Get Phame.
 *
 * Supported triggers:
 *  - WooCommerce: order status → processing / completed
 *  - WordPress:   new user registration (fallback for non-WooCommerce sites)
 *
 * @package GetPhameConnector
 */

defined( 'ABSPATH' ) || exit;

class GPC_Sync {

	public static function init(): void {
		// Only run if an API key is configured.
		if ( empty( get_option( 'gpc_api_key' ) ) ) {
			return;
		}

		// ── WooCommerce hooks ──────────────────────────────────────────────────
		// Trigger when an order moves to "processing" (payment received).
		add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'sync_from_woo_order' ), 10, 1 );

		// Trigger when an order moves to "completed".
		add_action( 'woocommerce_order_status_completed', array( __CLASS__, 'sync_from_woo_order' ), 10, 1 );

		// ── WordPress user registration fallback ───────────────────────────────
		if ( 'yes' === get_option( 'gpc_sync_wp_users', 'no' ) ) {
			add_action( 'user_register', array( __CLASS__, 'sync_from_wp_user' ), 10, 1 );
		}
	}

	// ─── WooCommerce ──────────────────────────────────────────────────────────

	/**
	 * Called on WooCommerce order status change.
	 * Extracts billing first name, last name, and email from the order.
	 *
	 * @param int $order_id WooCommerce order ID.
	 */
	public static function sync_from_woo_order( int $order_id ): void {
		// Avoid double-firing when an order transitions through multiple statuses.
		if ( get_post_meta( $order_id, '_gpc_synced', true ) === '1' ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		$first_name = $order->get_billing_first_name();
		$last_name  = $order->get_billing_last_name();
		$email      = $order->get_billing_email();

		if ( empty( $email ) || ! is_email( $email ) ) {
			GPC_Logger::log( sprintf( 'Order #%d skipped — no valid billing email.', $order_id ) );
			return;
		}

		// Queue the contact push (async via WP-Cron to avoid blocking the order flow).
		GPC_Queue::enqueue( $first_name, $last_name, $email, 'woocommerce', $order_id );

		// Mark order as synced to prevent duplicate pushes.
		update_post_meta( $order_id, '_gpc_synced', '1' );
	}

	// ─── WordPress Users ──────────────────────────────────────────────────────

	/**
	 * Called on new WordPress user registration.
	 *
	 * @param int $user_id WordPress user ID.
	 */
	public static function sync_from_wp_user( int $user_id ): void {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return;
		}

		$first_name = get_user_meta( $user_id, 'first_name', true ) ?: '';
		$last_name  = get_user_meta( $user_id, 'last_name', true ) ?: '';
		$email      = $user->user_email;

		if ( empty( $email ) || ! is_email( $email ) ) {
			return;
		}

		GPC_Queue::enqueue( $first_name, $last_name, $email, 'wordpress_user', $user_id );
	}

	// ─── Manual Bulk Sync ─────────────────────────────────────────────────────

	/**
	 * Bulk-sync existing WooCommerce customers (orders with status processing/completed).
	 * Triggered manually from the admin settings page.
	 *
	 * @param int $limit Max orders to process per run. Default 200.
	 * @return array{queued: int, skipped: int}
	 */
	public static function bulk_sync_woo_orders( int $limit = 200 ): array {
		if ( ! function_exists( 'wc_get_orders' ) ) {
			return array( 'queued' => 0, 'skipped' => 0 );
		}

		$orders = wc_get_orders(
			array(
				'status' => array( 'processing', 'completed' ),
				'limit'  => $limit,
				'return' => 'ids',
				'meta_query' => array(
					array(
						'key'     => '_gpc_synced',
						'compare' => 'NOT EXISTS',
					),
				),
			)
		);

		$queued  = 0;
		$skipped = 0;

		foreach ( $orders as $order_id ) {
			$order = wc_get_order( $order_id );
			if ( ! $order ) {
				++$skipped;
				continue;
			}

			$email = $order->get_billing_email();
			if ( empty( $email ) || ! is_email( $email ) ) {
				++$skipped;
				continue;
			}

			GPC_Queue::enqueue(
				$order->get_billing_first_name(),
				$order->get_billing_last_name(),
				$email,
				'woocommerce_bulk',
				$order_id
			);

			update_post_meta( $order_id, '_gpc_synced', '1' );
			++$queued;
		}

		GPC_Logger::log( sprintf( 'Bulk sync complete — queued: %d, skipped: %d.', $queued, $skipped ) );

		return array( 'queued' => $queued, 'skipped' => $skipped );
	}
}
