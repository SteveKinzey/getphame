<?php
/**
 * Get Phame Logger
 *
 * Lightweight log writer. Stores entries in the WordPress options table
 * (capped at 200 entries) so they are visible in the admin panel without
 * requiring filesystem write access.
 *
 * @package GetPhameConnector
 */

defined( 'ABSPATH' ) || exit;

class GPC_Logger {

	const OPTION_KEY = 'gpc_activity_log';
	const MAX_ENTRIES = 200;

	/**
	 * Append a message to the activity log.
	 *
	 * @param string $message Log message.
	 * @param string $level   'info' | 'warning' | 'error'
	 */
	public static function log( string $message, string $level = 'info' ): void {
		if ( 'yes' !== get_option( 'gpc_enable_logging', 'yes' ) ) {
			return;
		}

		$log = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $log ) ) {
			$log = array();
		}

		array_unshift(
			$log,
			array(
				'time'    => current_time( 'mysql' ),
				'level'   => $level,
				'message' => $message,
			)
		);

		// Keep only the most recent entries.
		if ( count( $log ) > self::MAX_ENTRIES ) {
			$log = array_slice( $log, 0, self::MAX_ENTRIES );
		}

		update_option( self::OPTION_KEY, $log, false );
	}

	/**
	 * Retrieve the activity log.
	 *
	 * @param int $limit Number of entries to return.
	 * @return array
	 */
	public static function get_log( int $limit = 50 ): array {
		$log = get_option( self::OPTION_KEY, array() );
		return array_slice( is_array( $log ) ? $log : array(), 0, $limit );
	}

	/**
	 * Clear the activity log.
	 */
	public static function clear(): void {
		update_option( self::OPTION_KEY, array(), false );
	}
}
