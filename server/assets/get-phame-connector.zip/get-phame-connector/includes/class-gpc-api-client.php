<?php
/**
 * Get Phame API Client
 *
 * Handles all HTTP communication with the Get Phame public REST API.
 * Endpoint: POST https://getphame.app/api/public/contacts
 * Auth:     Bearer <rl_...> API key generated inside Get Phame → Settings → API Keys.
 *
 * @package GetPhameConnector
 */

defined( 'ABSPATH' ) || exit;

class GPC_API_Client {

	/**
	 * Push a single contact to Get Phame.
	 *
	 * @param string $first_name Customer first name.
	 * @param string $last_name  Customer last name.
	 * @param string $email      Customer email address.
	 * @param string $api_key    Get Phame API key (rl_...).
	 *
	 * @return array{success: bool, created: bool, message: string}
	 */
	public static function push_contact( string $first_name, string $last_name, string $email, string $api_key ): array {
		$api_key = trim( $api_key );

		if ( empty( $api_key ) || ! str_starts_with( $api_key, 'rl_' ) ) {
			return array(
				'success' => false,
				'created' => false,
				'message' => __( 'Invalid API key format. Key must start with rl_', 'get-phame-connector' ),
			);
		}

		$name = trim( $first_name . ' ' . $last_name );
		if ( empty( $name ) ) {
			$name = explode( '@', $email )[0]; // Fallback: use email prefix as name.
		}

		$body = wp_json_encode(
			array(
				'name'  => sanitize_text_field( $name ),
				'email' => sanitize_email( $email ),
			)
		);

		$response = wp_remote_post(
			GPC_API_BASE . '/contacts',
			array(
				'timeout'     => 15,
				'redirection' => 3,
				'httpversion' => '1.1',
				'headers'     => array(
					'Content-Type'  => 'application/json',
					'Authorization' => 'Bearer ' . $api_key,
					'User-Agent'    => 'GetPhameConnector/' . GPC_VERSION . '; ' . get_bloginfo( 'url' ),
				),
				'body'        => $body,
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'created' => false,
				'message' => $response->get_error_message(),
			);
		}

		$status_code  = (int) wp_remote_retrieve_response_code( $response );
		$raw_body     = wp_remote_retrieve_body( $response );
		$decoded      = json_decode( $raw_body, true );
		$api_message  = $decoded['message'] ?? $decoded['error'] ?? $raw_body;

		if ( $status_code === 200 || $status_code === 201 ) {
			return array(
				'success' => true,
				'created' => ! empty( $decoded['created'] ),
				'message' => $api_message,
			);
		}

		return array(
			'success' => false,
			'created' => false,
			'message' => sprintf( 'HTTP %d — %s', $status_code, $api_message ),
		);
	}

	/**
	 * Validate an API key by pushing a test payload.
	 * Uses a clearly labelled test email that Get Phame deduplicates safely.
	 *
	 * @param string $api_key Get Phame API key.
	 * @return array{valid: bool, message: string}
	 */
	public static function validate_key( string $api_key ): array {
		$result = self::push_contact( 'Test', 'Connection', 'test-connection-do-not-send@getphame.app', $api_key );

		if ( $result['success'] ) {
			return array( 'valid' => true, 'message' => __( 'API key is valid. Connection successful.', 'get-phame-connector' ) );
		}

		return array( 'valid' => false, 'message' => $result['message'] );
	}
}
