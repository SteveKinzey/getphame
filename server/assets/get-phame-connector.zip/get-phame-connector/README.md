# Get Phame Connector

**Automatically sync your WooCommerce and WordPress customers to [Get Phame](https://getphame.app) so you can send review requests without manual imports.**

---

## What It Does

Every time a WooCommerce order reaches **Processing** or **Completed** status, this plugin pushes the customer's **first name, last name, and email** to your Get Phame contact list via the Get Phame Public API. Contacts are deduplicated automatically — no duplicate entries, no manual CSV exports.

For non-WooCommerce sites, an optional trigger syncs new **WordPress user registrations** instead.

---

## Features

| Feature | Detail |
|---|---|
| **Automatic sync** | Fires on WooCommerce order status change (processing / completed) |
| **Async queue** | Contacts are queued and pushed every 6 hours via WP-Cron — zero checkout performance impact |
| **Deduplication** | Skips contacts already in the queue or already sent |
| **Bulk sync** | One-click button to push all existing un-synced WooCommerce customers |
| **Activity log** | Last 200 sync events visible in the admin panel |
| **Connection test** | Validate your API key with a single click before going live |
| **Clean uninstall** | Drops the queue table and removes all options on plugin deletion |

---

## Requirements

- WordPress 6.0+
- PHP 8.0+
- WooCommerce 7.0+ *(optional — required for order-based sync)*
- A [Get Phame](https://getphame.app) account with an API key

---

## Installation

1. Upload the `get-phame-connector` folder to `/wp-content/plugins/`.
2. Activate the plugin via **WP Admin → Plugins**.
3. Go to **Settings → Get Phame** and paste your API key.
4. Click **Test Connection** to confirm the key is valid.
5. Save settings. The plugin will begin syncing automatically.

---

## Generating Your API Key

1. Log in to [getphame.app](https://getphame.app).
2. Go to **Settings → API Keys**.
3. Click **Generate New Key**, give it a label (e.g., `My WordPress Site`).
4. Copy the key (starts with `rl_`) and paste it into the plugin settings.

---

## API Endpoint Used

```
POST https://getphame.app/api/public/contacts
Authorization: Bearer rl_<your_key>
Content-Type: application/json

{
  "name":  "Jane Smith",
  "email": "jane@example.com"
}
```

**Response:**
```json
{ "success": true, "created": true, "id": 1234 }
```

Contacts are deduplicated server-side by email address per account.

---

## File Structure

```
get-phame-connector/
├── get-phame-connector.php       # Plugin bootstrap & constants
├── uninstall.php                 # Clean removal of all data
├── includes/
│   ├── class-gpc-api-client.php  # HTTP calls to Get Phame API
│   ├── class-gpc-sync.php        # WooCommerce & WP user hooks
│   ├── class-gpc-queue.php       # Async queue + WP-Cron processor
│   └── class-gpc-logger.php      # Activity log (options table)
├── admin/
│   └── class-gpc-admin.php       # Settings page, AJAX handlers
└── assets/
    ├── css/admin.css
    └── js/admin.js
```

---

## Changelog

### 1.0.0 — Initial Release
- WooCommerce order sync (processing / completed)
- WordPress user registration sync (optional)
- Async queue with WP-Cron (6-hour interval, batch of 30)
- Bulk sync for existing customers
- Activity log (last 200 events)
- API key connection test
- Clean uninstall

---

## License

GPL-2.0-or-later — see [LICENSE](LICENSE)

---

## Author

**SK America, LLC** — [sk-america.com](https://sk-america.com)
