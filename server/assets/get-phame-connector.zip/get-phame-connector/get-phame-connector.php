<?php
/**
 * Plugin Name:       Get Phame Connector
 * Plugin URI:        https://getphame.app
 * Description:       Automatically syncs WooCommerce and WordPress customer data (first name, last name, email) to your Get Phame account so you can send review requests without manual imports.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            SK America, LLC
 * Author URI:        https://sk-america.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       get-phame-connector
 * Domain Path:       /languages
 *
 * @package GetPhameConnector
 */

defined( 'ABSPATH' ) || exit;

// ─── Constants ────────────────────────────────────────────────────────────────
define( 'GPC_VERSION',     '1.0.0' );
define( 'GPC_PLUGIN_FILE', __FILE__ );
define( 'GPC_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'GPC_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'GPC_API_BASE',    'https://getphame.app/api/public' );

// ─── Autoload includes ────────────────────────────────────────────────────────
require_once GPC_PLUGIN_DIR . 'includes/class-gpc-api-client.php';
require_once GPC_PLUGIN_DIR . 'includes/class-gpc-sync.php';
require_once GPC_PLUGIN_DIR . 'includes/class-gpc-queue.php';
require_once GPC_PLUGIN_DIR . 'includes/class-gpc-logger.php';
require_once GPC_PLUGIN_DIR . 'admin/class-gpc-admin.php';

// ─── Bootstrap ────────────────────────────────────────────────────────────────
add_action( 'plugins_loaded', array( 'GPC_Sync', 'init' ) );
add_action( 'plugins_loaded', array( 'GPC_Admin', 'init' ) );
add_action( 'plugins_loaded', array( 'GPC_Queue', 'init' ) );

// ─── Activation / Deactivation / Uninstall ────────────────────────────────────
register_activation_hook(   __FILE__, array( 'GPC_Queue', 'create_table' ) );
register_deactivation_hook( __FILE__, array( 'GPC_Queue', 'clear_cron' ) );
