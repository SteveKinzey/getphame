<?php
/**
 * Get Phame Connector — Uninstall
 *
 * Runs when the plugin is deleted from WP Admin → Plugins.
 * Removes all plugin options and drops the queue table.
 *
 * @package GetPhameConnector
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

// ── Remove all plugin options ──────────────────────────────────────────────────
$options = array(
	'gpc_api_key',
	'gpc_sync_woo',
	'gpc_sync_wp_users',
	'gpc_enable_logging',
	'gpc_activity_log',
	'gpc_db_version',
);

foreach ( $options as $option ) {
	delete_option( $option );
}

// ── Drop the queue table ───────────────────────────────────────────────────────
global $wpdb;
// phpcs:ignore WordPress.DB.DirectDatabaseQuery
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}gpc_queue" );
