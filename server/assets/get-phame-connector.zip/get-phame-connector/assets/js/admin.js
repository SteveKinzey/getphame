/* Get Phame Connector — Admin JS */
/* global GPC, jQuery */

( function ( $ ) {
	'use strict';

	// ── Test Connection ────────────────────────────────────────────────────────
	$( '#gpc-test-btn' ).on( 'click', function () {
		var $btn    = $( this );
		var $result = $( '#gpc-test-result' );
		var apiKey  = $( '#gpc_api_key' ).val().trim();

		if ( ! apiKey ) {
			$result.removeClass( 'success' ).addClass( 'error' ).text( 'Enter an API key first.' );
			return;
		}

		$btn.prop( 'disabled', true ).text( GPC.i18n.testing );
		$result.removeClass( 'success error' ).text( '' );

		$.post( GPC.ajax_url, {
			action:  'gpc_test_connection',
			nonce:   GPC.nonce,
			api_key: apiKey,
		} )
		.done( function ( res ) {
			if ( res.success ) {
				$result.addClass( 'success' ).text( '✓ ' + res.data.message );
			} else {
				$result.addClass( 'error' ).text( '✗ ' + res.data.message );
			}
		} )
		.fail( function () {
			$result.addClass( 'error' ).text( '✗ Request failed. Check your server.' );
		} )
		.always( function () {
			$btn.prop( 'disabled', false ).text( 'Test Connection' );
		} );
	} );

	// ── Bulk Sync ─────────────────────────────────────────────────────────────
	$( '#gpc-bulk-btn' ).on( 'click', function () {
		var $btn    = $( this );
		var $result = $( '#gpc-bulk-result' );

		if ( ! confirm( 'This will queue all un-synced WooCommerce customers (up to 200 per run). Continue?' ) ) {
			return;
		}

		$btn.prop( 'disabled', true ).text( GPC.i18n.syncing );
		$result.removeClass( 'success error' ).text( '' );

		$.post( GPC.ajax_url, {
			action: 'gpc_bulk_sync',
			nonce:  GPC.nonce,
		} )
		.done( function ( res ) {
			if ( res.success ) {
				$result.addClass( 'success' ).text( '✓ ' + res.data.message );
			} else {
				$result.addClass( 'error' ).text( '✗ ' + res.data.message );
			}
		} )
		.fail( function () {
			$result.addClass( 'error' ).text( '✗ Request failed.' );
		} )
		.always( function () {
			$btn.prop( 'disabled', false ).text( 'Run Bulk Sync Now' );
		} );
	} );

	// ── Clear Log ─────────────────────────────────────────────────────────────
	$( '#gpc-clear-log-btn' ).on( 'click', function () {
		if ( ! confirm( 'Clear the activity log? This cannot be undone.' ) ) {
			return;
		}

		var $btn = $( this );
		$btn.prop( 'disabled', true ).text( GPC.i18n.clearing );

		$.post( GPC.ajax_url, {
			action: 'gpc_clear_log',
			nonce:  GPC.nonce,
		} )
		.done( function ( res ) {
			if ( res.success ) {
				$( '.gpc-log-table' ).replaceWith( '<p class="description">Log cleared.</p>' );
			}
		} )
		.always( function () {
			$btn.prop( 'disabled', false ).text( 'Clear Log' );
		} );
	} );

	// ── Enable test button when API key is typed ───────────────────────────────
	$( '#gpc_api_key' ).on( 'input', function () {
		var hasKey = $( this ).val().trim().length > 0;
		$( '#gpc-test-btn' ).prop( 'disabled', ! hasKey );
		$( '#gpc-bulk-btn' ).prop( 'disabled', ! hasKey );
	} );

} )( jQuery );
