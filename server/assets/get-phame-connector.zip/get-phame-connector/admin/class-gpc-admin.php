<?php
/**
 * Get Phame Admin
 *
 * Registers the Settings page under WP Admin → Settings → Get Phame Connector.
 * Provides:
 *  - API key input + live connection test
 *  - Sync trigger toggles (WooCommerce orders, WP user registration)
 *  - Manual bulk sync button
 *  - Queue status dashboard (pending / sent / failed counts)
 *  - Activity log viewer
 *
 * @package GetPhameConnector
 */

defined( 'ABSPATH' ) || exit;

class GPC_Admin {

	const PAGE_SLUG    = 'get-phame-connector';
	const OPTION_GROUP = 'gpc_settings';

	public static function init(): void {
		add_action( 'admin_menu',    array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_init',    array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );

		// AJAX handlers.
		add_action( 'wp_ajax_gpc_test_connection', array( __CLASS__, 'ajax_test_connection' ) );
		add_action( 'wp_ajax_gpc_bulk_sync',       array( __CLASS__, 'ajax_bulk_sync' ) );
		add_action( 'wp_ajax_gpc_clear_log',       array( __CLASS__, 'ajax_clear_log' ) );
	}

	// ─── Menu ─────────────────────────────────────────────────────────────────

	public static function register_menu(): void {
		add_options_page(
			__( 'Get Phame Connector', 'get-phame-connector' ),
			__( 'Get Phame', 'get-phame-connector' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_settings_page' )
		);
	}

	// ─── Settings Registration ────────────────────────────────────────────────

	public static function register_settings(): void {
		register_setting( self::OPTION_GROUP, 'gpc_api_key',        array( 'sanitize_callback' => 'sanitize_text_field' ) );
		register_setting( self::OPTION_GROUP, 'gpc_sync_woo',       array( 'sanitize_callback' => 'sanitize_text_field', 'default' => 'yes' ) );
		register_setting( self::OPTION_GROUP, 'gpc_sync_wp_users',  array( 'sanitize_callback' => 'sanitize_text_field', 'default' => 'no' ) );
		register_setting( self::OPTION_GROUP, 'gpc_enable_logging', array( 'sanitize_callback' => 'sanitize_text_field', 'default' => 'yes' ) );
	}

	// ─── Assets ───────────────────────────────────────────────────────────────

	public static function enqueue_assets( string $hook ): void {
		if ( 'settings_page_' . self::PAGE_SLUG !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'gpc-admin',
			GPC_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			GPC_VERSION
		);

		wp_enqueue_script(
			'gpc-admin',
			GPC_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			GPC_VERSION,
			true
		);

		wp_localize_script(
			'gpc-admin',
			'GPC',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'gpc_admin_nonce' ),
				'i18n'     => array(
					'testing'     => __( 'Testing…', 'get-phame-connector' ),
					'syncing'     => __( 'Syncing…', 'get-phame-connector' ),
					'clearing'    => __( 'Clearing…', 'get-phame-connector' ),
				),
			)
		);
	}

	// ─── Settings Page Render ─────────────────────────────────────────────────

	public static function render_settings_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$api_key       = get_option( 'gpc_api_key', '' );
		$sync_woo      = get_option( 'gpc_sync_woo', 'yes' );
		$sync_wp_users = get_option( 'gpc_sync_wp_users', 'no' );
		$logging       = get_option( 'gpc_enable_logging', 'yes' );
		$stats         = GPC_Queue::get_stats();
		$log_entries   = GPC_Logger::get_log( 50 );
		$woo_active    = class_exists( 'WooCommerce' );
		?>
		<div class="wrap gpc-wrap">

			<div class="gpc-header">
				<h1>
					<span class="gpc-logo">⭐</span>
					<?php esc_html_e( 'Get Phame Connector', 'get-phame-connector' ); ?>
				</h1>
				<p class="gpc-tagline"><?php esc_html_e( 'Automatically sync your customers to Get Phame and start collecting more reviews.', 'get-phame-connector' ); ?></p>
			</div>

			<?php settings_errors( self::OPTION_GROUP ); ?>

			<div class="gpc-grid">

				<!-- ── Left Column: Settings ── -->
				<div class="gpc-col-main">

					<form method="post" action="options.php">
						<?php settings_fields( self::OPTION_GROUP ); ?>

						<!-- API Key -->
						<div class="gpc-card">
							<h2><?php esc_html_e( 'API Key', 'get-phame-connector' ); ?></h2>
							<p><?php esc_html_e( 'Generate your API key inside Get Phame → Settings → API Keys. Keys start with rl_.', 'get-phame-connector' ); ?></p>
							<table class="form-table" role="presentation">
								<tr>
									<th scope="row">
										<label for="gpc_api_key"><?php esc_html_e( 'Get Phame API Key', 'get-phame-connector' ); ?></label>
									</th>
									<td>
										<input
											type="password"
											id="gpc_api_key"
											name="gpc_api_key"
											value="<?php echo esc_attr( $api_key ); ?>"
											class="regular-text"
											autocomplete="new-password"
											placeholder="rl_..."
										/>
										<button type="button" id="gpc-test-btn" class="button button-secondary" <?php echo empty( $api_key ) ? 'disabled' : ''; ?>>
											<?php esc_html_e( 'Test Connection', 'get-phame-connector' ); ?>
										</button>
										<span id="gpc-test-result" class="gpc-inline-result"></span>
									</td>
								</tr>
							</table>
						</div>

						<!-- Sync Triggers -->
						<div class="gpc-card">
							<h2><?php esc_html_e( 'Sync Triggers', 'get-phame-connector' ); ?></h2>
							<table class="form-table" role="presentation">
								<tr>
									<th scope="row"><?php esc_html_e( 'WooCommerce Orders', 'get-phame-connector' ); ?></th>
									<td>
										<label>
											<input type="checkbox" name="gpc_sync_woo" value="yes" <?php checked( $sync_woo, 'yes' ); ?> <?php echo ! $woo_active ? 'disabled' : ''; ?> />
											<?php esc_html_e( 'Sync customer on order status → Processing or Completed', 'get-phame-connector' ); ?>
										</label>
										<?php if ( ! $woo_active ) : ?>
											<p class="description gpc-warn"><?php esc_html_e( 'WooCommerce is not active.', 'get-phame-connector' ); ?></p>
										<?php endif; ?>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php esc_html_e( 'WordPress User Registration', 'get-phame-connector' ); ?></th>
									<td>
										<label>
											<input type="checkbox" name="gpc_sync_wp_users" value="yes" <?php checked( $sync_wp_users, 'yes' ); ?> />
											<?php esc_html_e( 'Sync new WordPress user registrations (useful for non-WooCommerce sites)', 'get-phame-connector' ); ?>
										</label>
									</td>
								</tr>
								<tr>
									<th scope="row"><?php esc_html_e( 'Activity Logging', 'get-phame-connector' ); ?></th>
									<td>
										<label>
											<input type="checkbox" name="gpc_enable_logging" value="yes" <?php checked( $logging, 'yes' ); ?> />
											<?php esc_html_e( 'Enable activity log (last 200 events)', 'get-phame-connector' ); ?>
										</label>
									</td>
								</tr>
							</table>
						</div>

						<?php submit_button( __( 'Save Settings', 'get-phame-connector' ) ); ?>
					</form>

				</div>

				<!-- ── Right Column: Stats + Bulk Sync ── -->
				<div class="gpc-col-side">

					<!-- Queue Stats -->
					<div class="gpc-card gpc-stats-card">
						<h2><?php esc_html_e( 'Sync Queue', 'get-phame-connector' ); ?></h2>
						<div class="gpc-stats-grid">
							<div class="gpc-stat gpc-stat--pending">
								<span class="gpc-stat__num"><?php echo esc_html( $stats['pending'] ); ?></span>
								<span class="gpc-stat__label"><?php esc_html_e( 'Pending', 'get-phame-connector' ); ?></span>
							</div>
							<div class="gpc-stat gpc-stat--sent">
								<span class="gpc-stat__num"><?php echo esc_html( $stats['sent'] ); ?></span>
								<span class="gpc-stat__label"><?php esc_html_e( 'Sent', 'get-phame-connector' ); ?></span>
							</div>
							<div class="gpc-stat gpc-stat--failed">
								<span class="gpc-stat__num"><?php echo esc_html( $stats['failed'] ); ?></span>
								<span class="gpc-stat__label"><?php esc_html_e( 'Failed', 'get-phame-connector' ); ?></span>
							</div>
						</div>
						<p class="description"><?php esc_html_e( 'Queue is processed every 6 hours via WP-Cron.', 'get-phame-connector' ); ?></p>
					</div>

					<!-- Bulk Sync -->
					<?php if ( $woo_active ) : ?>
					<div class="gpc-card">
						<h2><?php esc_html_e( 'Bulk Sync', 'get-phame-connector' ); ?></h2>
						<p><?php esc_html_e( 'Push all existing WooCommerce customers (processing/completed orders) who have not yet been synced.', 'get-phame-connector' ); ?></p>
						<button type="button" id="gpc-bulk-btn" class="button button-primary" <?php echo empty( $api_key ) ? 'disabled' : ''; ?>>
							<?php esc_html_e( 'Run Bulk Sync Now', 'get-phame-connector' ); ?>
						</button>
						<span id="gpc-bulk-result" class="gpc-inline-result" style="display:block;margin-top:8px;"></span>
					</div>
					<?php endif; ?>

					<!-- Quick Links -->
					<div class="gpc-card">
						<h2><?php esc_html_e( 'Quick Links', 'get-phame-connector' ); ?></h2>
						<ul class="gpc-links">
							<li><a href="https://getphame.app" target="_blank" rel="noopener">🌐 <?php esc_html_e( 'Open Get Phame', 'get-phame-connector' ); ?></a></li>
							<li><a href="https://getphame.app" target="_blank" rel="noopener">🔑 <?php esc_html_e( 'Generate API Key', 'get-phame-connector' ); ?></a></li>
							<li><a href="https://getphame.app" target="_blank" rel="noopener">📖 <?php esc_html_e( 'Documentation', 'get-phame-connector' ); ?></a></li>
						</ul>
					</div>

				</div>
			</div>

			<!-- Activity Log -->
			<div class="gpc-card gpc-log-card">
				<div class="gpc-log-header">
					<h2><?php esc_html_e( 'Activity Log', 'get-phame-connector' ); ?></h2>
					<button type="button" id="gpc-clear-log-btn" class="button button-link-delete"><?php esc_html_e( 'Clear Log', 'get-phame-connector' ); ?></button>
				</div>
				<?php if ( empty( $log_entries ) ) : ?>
					<p class="description"><?php esc_html_e( 'No activity yet. Contacts will appear here once synced.', 'get-phame-connector' ); ?></p>
				<?php else : ?>
					<table class="widefat striped gpc-log-table">
						<thead>
							<tr>
								<th><?php esc_html_e( 'Time', 'get-phame-connector' ); ?></th>
								<th><?php esc_html_e( 'Level', 'get-phame-connector' ); ?></th>
								<th><?php esc_html_e( 'Message', 'get-phame-connector' ); ?></th>
							</tr>
						</thead>
						<tbody>
							<?php foreach ( $log_entries as $entry ) : ?>
								<tr>
									<td><?php echo esc_html( $entry['time'] ); ?></td>
									<td><span class="gpc-badge gpc-badge--<?php echo esc_attr( $entry['level'] ); ?>"><?php echo esc_html( $entry['level'] ); ?></span></td>
									<td><?php echo esc_html( $entry['message'] ); ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>
			</div>

		</div>
		<?php
	}

	// ─── AJAX Handlers ────────────────────────────────────────────────────────

	public static function ajax_test_connection(): void {
		check_ajax_referer( 'gpc_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'get-phame-connector' ) ) );
		}

		$api_key = sanitize_text_field( wp_unslash( $_POST['api_key'] ?? '' ) );
		$result  = GPC_API_Client::validate_key( $api_key );

		if ( $result['valid'] ) {
			wp_send_json_success( array( 'message' => $result['message'] ) );
		} else {
			wp_send_json_error( array( 'message' => $result['message'] ) );
		}
	}

	public static function ajax_bulk_sync(): void {
		check_ajax_referer( 'gpc_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'get-phame-connector' ) ) );
		}

		$result = GPC_Sync::bulk_sync_woo_orders( 200 );

		wp_send_json_success(
			array(
				'message' => sprintf(
					/* translators: 1: queued count, 2: skipped count */
					__( 'Done. %1$d contacts queued, %2$d skipped (already synced or no email).', 'get-phame-connector' ),
					$result['queued'],
					$result['skipped']
				),
			)
		);
	}

	public static function ajax_clear_log(): void {
		check_ajax_referer( 'gpc_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'get-phame-connector' ) ) );
		}

		GPC_Logger::clear();
		wp_send_json_success( array( 'message' => __( 'Log cleared.', 'get-phame-connector' ) ) );
	}
}
